# Semáforo Uber

## Compilar sin Android Studio (desde el celu)
1. Creá un repositorio en GitHub y subí esta carpeta tal cual (incluida la carpeta .github).
2. Pestaña Actions → "Compilar APK" corre solo (o tocá Run workflow).
3. Cuando termina, bajás "semaforo-uber-apk" y adentro está el .apk.

## Compilar con Android Studio
Abrir la carpeta → Build → Build APK(s).

## Instalar y activar
1. Instalá el APK (permití "orígenes desconocidos").
2. Android 13 o más: Ajustes → Apps → Semáforo Uber → menú ⋮ → "Permitir configuración restringida".
3. Abrí la app → "Activar el semáforo" → prendé "Semáforo Uber" en Accesibilidad.
4. Cargá tus números (costo por km y ganancia por hora) y guardá.
