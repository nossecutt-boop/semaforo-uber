package ar.eds.semaforo

import android.app.Activity
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var estado: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        estado = findViewById(R.id.estado)
        val costo = findViewById<EditText>(R.id.costoKm)
        val objetivo = findViewById<EditText>(R.id.objetivoHora)
        val banda = findViewById<EditText>(R.id.banda)

        costo.setText(Prefs.costoKm(this).toLong().toString())
        objetivo.setText(Prefs.objetivoHora(this).toLong().toString())
        banda.setText((Prefs.banda(this) * 100).toLong().toString())

        findViewById<Button>(R.id.btnActivar).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        val guardarNumeros = {
            Prefs.guardar(
                this,
                Parser.decimal(costo.text.toString()),
                Parser.plata(objetivo.text.toString()),
                Parser.decimal(banda.text.toString()) / 100.0
            )
        }
        findViewById<Button>(R.id.btnGuardar).setOnClickListener {
            guardarNumeros()
            Toast.makeText(this, "Números guardados", Toast.LENGTH_SHORT).show()
        }

        apagarLuces()
        findViewById<Button>(R.id.btnProbar).setOnClickListener {
            guardarNumeros()
            val o = Oferta(
                Parser.plata(findViewById<EditText>(R.id.pPrecio).text.toString()),
                Parser.decimal(findViewById<EditText>(R.id.pKm).text.toString()),
                Parser.decimal(findViewById<EditText>(R.id.pMin).text.toString())
            )
            val res = findViewById<TextView>(R.id.resultado)
            if (o.precio <= 0 || o.km <= 0 || o.min <= 0) {
                res.text = "Completá precio, km y minutos con números mayores a cero."
                apagarLuces()
                return@setOnClickListener
            }
            val r = Evaluador.evaluar(o, Prefs.costoKm(this), Prefs.objetivoHora(this), Prefs.banda(this))
            prender(r.luz)
            res.text = "${pesos(r.netaHora)} por hora\n" +
                "Te quedan ${pesos(r.neta)}\n" +
                "${pesos(r.netaKm)} netos por km"
        }

        val sw = findViewById<Switch>(R.id.swDiag)
        sw.isChecked = Prefs.diagnostico(this)
        sw.setOnCheckedChangeListener { _, on -> Prefs.setDiagnostico(this, on) }

        findViewById<Button>(R.id.btnVerDiag).setOnClickListener {
            val t = Prefs.ultimoTexto(this)
            val a = Prefs.actividad(this)
            findViewById<TextView>(R.id.diag).text =
                (if (t.isBlank()) "Ninguna oferta leída todavía." else t) +
                "\n\n=== Actividad ===\n" +
                a.ifBlank { "Sin actividad de Uber. ¿Está prendido en Accesibilidad?" }
        }
    }

    override fun onResume() {
        super.onResume()
        estado.text = if (servicioActivo())
            "Activo. Abrí Uber Driver y el semáforo aparece con cada oferta."
        else
            "Apagado. Tocá el botón y prendé “Semáforo Uber” en Accesibilidad."
    }

    private fun servicioActivo(): Boolean {
        val lista = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return lista.contains("$packageName/") && lista.contains("SemaforoService")
    }

    private fun circulo(v: View, color: Int) {
        v.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
    }

    private fun apagarLuces() {
        circulo(findViewById(R.id.luzRoja), 0xFF4A2224.toInt())
        circulo(findViewById(R.id.luzAmarilla), 0xFF4A3D14.toInt())
        circulo(findViewById(R.id.luzVerde), 0xFF1D3F2C.toInt())
    }

    private fun prender(l: Luz) {
        apagarLuces()
        when (l) {
            Luz.ROJO -> circulo(findViewById(R.id.luzRoja), getColor(R.color.rojo))
            Luz.AMARILLO -> circulo(findViewById(R.id.luzAmarilla), getColor(R.color.ambar))
            Luz.VERDE -> circulo(findViewById(R.id.luzVerde), getColor(R.color.verde))
        }
    }
}
