package ar.eds.semaforo

import java.util.Locale
import kotlin.math.max

enum class Luz { VERDE, AMARILLO, ROJO }

data class Oferta(val precio: Double, val km: Double, val min: Double)

data class Resultado(val luz: Luz, val neta: Double, val netaHora: Double, val netaKm: Double)

object Evaluador {
    fun evaluar(o: Oferta, costoKm: Double, objetivoHora: Double, banda: Double): Resultado {
        val neta = o.precio - o.km * costoKm
        val netaHora = neta / (max(o.min, 1.0) / 60.0)
        val netaKm = if (o.km > 0) neta / o.km else 0.0
        val luz = when {
            neta <= 0 -> Luz.ROJO
            netaHora >= objetivoHora -> Luz.VERDE
            netaHora >= objetivoHora * banda -> Luz.AMARILLO
            else -> Luz.ROJO
        }
        return Resultado(luz, neta, netaHora, netaKm)
    }
}

private val AR = Locale("es", "AR")
fun pesos(x: Double): String = "$ " + String.format(AR, "%,.0f", x)
fun dec(x: Double): String = String.format(AR, "%.1f", x)
