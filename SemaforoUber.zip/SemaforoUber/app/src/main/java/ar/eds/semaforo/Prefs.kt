package ar.eds.semaforo

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("semaforo", Context.MODE_PRIVATE)

    // Valores de arranque: ajustalos en la app con tus números reales.
    fun costoKm(c: Context) = sp(c).getFloat("costoKm", 250f).toDouble()
    fun objetivoHora(c: Context) = sp(c).getFloat("objetivoHora", 10000f).toDouble()
    fun banda(c: Context) = sp(c).getFloat("banda", 0.8f).toDouble()

    fun guardar(c: Context, costoKm: Double, objetivoHora: Double, banda: Double) {
        sp(c).edit()
            .putFloat("costoKm", costoKm.toFloat())
            .putFloat("objetivoHora", objetivoHora.toFloat())
            .putFloat("banda", banda.coerceIn(0.1, 1.0).toFloat())
            .apply()
    }

    fun diagnostico(c: Context) = sp(c).getBoolean("diag", false)
    fun setDiagnostico(c: Context, on: Boolean) = sp(c).edit().putBoolean("diag", on).apply()
    fun ultimoTexto(c: Context) = sp(c).getString("ultimoTexto", "") ?: ""
    fun setUltimoTexto(c: Context, t: String) = sp(c).edit().putString("ultimoTexto", t).apply()
    fun actividad(c: Context) = sp(c).getString("actividad", "") ?: ""
    fun setActividad(c: Context, t: String) = sp(c).edit().putString("actividad", t).apply()
}
