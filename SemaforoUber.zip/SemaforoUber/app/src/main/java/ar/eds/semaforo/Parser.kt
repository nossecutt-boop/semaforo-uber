package ar.eds.semaforo

import kotlin.math.abs

/**
 * Saca precio, km y minutos de la tarjeta de oferta de Uber Driver.
 * Formato real visto: "ARS3,407"  "ARS668/km est."
 *   "A 8 min (3.2 km) de distancia"  "Viaje: 5 min (1.9 km)"
 * También entiende "A 2 min (800 m)" y "Viaje: 1 h 5 min (40 km)".
 * Suma el trayecto hasta el pasajero + el viaje.
 */
object Parser {
    private val dinero = Regex("""(?:\$|ARS)\s?(\d[\d.,]*)""")

    // [horas h] [minutos min] (distancia km|m)
    private val tramo = Regex(
        """(?:(\d+)\s*h(?:s|r|rs)?\.?\s*)?(?:(\d+)\s*min\.?\s*)?\(\s*(\d+(?:[.,]\d+)?)\s*(km|m)\s*\)""",
        RegexOption.IGNORE_CASE
    )
    private val soloKm = Regex("""(\d+(?:[.,]\d+)?)\s*km\b""", RegexOption.IGNORE_CASE)
    private val soloMin = Regex("""(\d+)\s*min\b""", RegexOption.IGNORE_CASE)

    private class Monto(val valor: Double, val porKm: Boolean, val pos: Int)

    fun parsear(textosCrudos: List<String>): Oferta? {
        // El mismo texto puede llegar repetido (texto + descripción, ventana + evento).
        val todo = textosCrudos.map { it.trim() }.filter { it.isNotEmpty() }.distinct().joinToString(" | ")

        // 1) Km y minutos: cada tramo distinto se cuenta una sola vez.
        var km = 0.0
        var min = 0.0
        val vistos = HashSet<String>()
        for (m in tramo.findAll(todo)) {
            val h = m.groupValues[1]
            val mi = m.groupValues[2]
            if (h.isEmpty() && mi.isEmpty()) continue
            val minutos = (h.toDoubleOrNull() ?: 0.0) * 60 + (mi.toDoubleOrNull() ?: 0.0)
            var dist = decimal(m.groupValues[3])
            if (m.groupValues[4].equals("m", ignoreCase = true)) dist /= 1000.0
            if (vistos.add("$minutos|$dist")) {
                min += minutos
                km += dist
            }
        }
        if (vistos.isEmpty()) {
            km = soloKm.findAll(todo).map { decimal(it.groupValues[1]) }.distinct().sum()
            min = soloMin.findAll(todo).map { it.groupValues[1].toDouble() }.distinct().sum()
        }
        if (km <= 0 || min <= 0) return null

        // 2) Precio: en pantalla puede haber otros montos (ganancias del día, etc.).
        val montos = dinero.findAll(todo).map {
            Monto(plata(it.groupValues[1]), todo.startsWith("/km", it.range.last + 1), it.range.first)
        }.filter { it.valor > 0 }.toList()
        val porKm = montos.firstOrNull { it.porKm }
        val candidatos = montos.filter { !it.porKm }
        if (candidatos.isEmpty()) return null

        val precio = if (porKm != null) {
            // Uber muestra "ARSxxx/km est." = precio / km totales. El que cuadre, es el precio.
            candidatos.minByOrNull { abs(it.valor / km - porKm.valor) }
                ?.takeIf { abs(it.valor / km - porKm.valor) <= porKm.valor * 0.25 }?.valor
                ?: candidatos.lastOrNull { it.pos < porKm.pos }?.valor
                ?: candidatos.first().valor
        } else {
            candidatos.first().valor
        }
        return Oferta(precio, km, min)
    }

    /**
     * Entiende "3,407" "3.407" "4.523,50" "12,345.67" "3500".
     * Un separador seguido de exactamente 3 dígitos es de miles.
     */
    fun plata(entrada: String): Double {
        var s = entrada.trim().replace(" ", "").trimEnd('.', ',')
        val punto = s.lastIndexOf('.')
        val coma = s.lastIndexOf(',')
        if (punto >= 0 && coma >= 0) {
            val dec = if (punto > coma) '.' else ','
            val miles = if (dec == '.') "," else "."
            s = s.replace(miles, "").replace(dec, '.')
        } else if (punto >= 0 || coma >= 0) {
            val sep = if (punto >= 0) '.' else ','
            val partes = s.split(sep)
            s = if (partes.size > 2 || partes.last().length == 3) s.replace(sep.toString(), "")
                else s.replace(sep, '.')
        }
        return s.toDoubleOrNull() ?: 0.0
    }

    fun decimal(s: String): Double = s.replace(",", ".").toDoubleOrNull() ?: 0.0
}
