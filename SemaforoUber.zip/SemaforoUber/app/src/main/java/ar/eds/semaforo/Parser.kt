package ar.eds.semaforo

/**
 * Saca precio, km y minutos del texto de la tarjeta de oferta de Uber Driver.
 * Formato típico: "$ 4.523,50"  "5 min (1,2 km)"  "18 min (9,4 km)".
 * Suma el trayecto hasta el pasajero + el viaje.
 */
object Parser {
    private val dinero = Regex("""(?:\$|ARS)\s?(\d{1,3}(?:[.\s]\d{3})+(?:,\d{1,2})?|\d+(?:,\d{1,2})?)""")
    private val minKm = Regex("""(\d+)\s*min\.?\s*\(\s*(\d+(?:[.,]\d+)?)\s*km\s*\)""", RegexOption.IGNORE_CASE)
    private val soloKm = Regex("""(\d+(?:[.,]\d+)?)\s*km\b""", RegexOption.IGNORE_CASE)
    private val soloMin = Regex("""(\d+)\s*min\b""", RegexOption.IGNORE_CASE)

    fun parsear(textos: List<String>): Oferta? {
        val todo = textos.joinToString(" | ")
        val precio = dinero.find(todo)?.let { plata(it.groupValues[1]) } ?: return null
        if (precio <= 0) return null

        var km = 0.0
        var min = 0.0
        val pares = minKm.findAll(todo).toList()
        if (pares.isNotEmpty()) {
            for (p in pares) {
                min += p.groupValues[1].toDouble()
                km += decimal(p.groupValues[2])
            }
        } else {
            km = soloKm.findAll(todo).sumOf { decimal(it.groupValues[1]) }
            min = soloMin.findAll(todo).sumOf { it.groupValues[1].toDouble() }
        }
        if (km <= 0 || min <= 0) return null
        return Oferta(precio, km, min)
    }

    fun plata(s: String): Double =
        s.replace(" ", "").replace(".", "").replace(",", ".").toDoubleOrNull() ?: 0.0

    fun decimal(s: String): Double = s.replace(",", ".").toDoubleOrNull() ?: 0.0
}
