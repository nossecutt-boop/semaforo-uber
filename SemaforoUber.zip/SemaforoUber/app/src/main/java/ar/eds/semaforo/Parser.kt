package ar.eds.semaforo

/**
 * Saca precio, km y minutos de la tarjeta de oferta de Uber Driver.
 * Formato real visto: "ARS3,407"  "ARS668/km est."
 *   "A 8 min (3.2 km) de distancia"  "Viaje: 5 min (1.9 km)"
 * Suma el trayecto hasta el pasajero + el viaje.
 */
object Parser {
    private val dinero = Regex("""(?:\$|ARS)\s?(\d[\d.,]*)""")
    private val minKm = Regex("""(\d+)\s*min\.?\s*\(\s*(\d+(?:[.,]\d+)?)\s*km\s*\)""", RegexOption.IGNORE_CASE)
    private val soloKm = Regex("""(\d+(?:[.,]\d+)?)\s*km\b""", RegexOption.IGNORE_CASE)
    private val soloMin = Regex("""(\d+)\s*min\b""", RegexOption.IGNORE_CASE)

    fun parsear(textos: List<String>): Oferta? {
        val todo = textos.joinToString(" | ")
        // El primer monto que no sea "/km" es el precio del viaje.
        val precio = dinero.findAll(todo)
            .filterNot { todo.startsWith("/km", it.range.last + 1) }
            .map { plata(it.groupValues[1]) }
            .firstOrNull { it > 0 } ?: return null

        var km = 0.0
        var min = 0.0
        val pares = minKm.findAll(todo).toList()
        if (pares.isNotEmpty()) {
            for (p in pares) {
                min += p.groupValues[1].toDouble()
                km += decimal(p.groupValues[2])
            }
        } else {
            km = soloKm.findAll(todo).sumOf { decimal(it.groupValues[1]) }
            min = soloMin.findAll(todo).sumOf { it.groupValues[1].toDouble() }
        }
        if (km <= 0 || min <= 0) return null
        return Oferta(precio, km, min)
    }

    /**
     * Entiende "3,407" "3.407" "4.523,50" "12,345.67" "3500".
     * Un separador seguido de exactamente 3 dígitos es de miles.
     */
    fun plata(entrada: String): Double {
        var s = entrada.trim().replace(" ", "").trimEnd('.', ',')
        val punto = s.lastIndexOf('.')
        val coma = s.lastIndexOf(',')
        if (punto >= 0 && coma >= 0) {
            val dec = if (punto > coma) '.' else ','
            val miles = if (dec == '.') "," else "."
            s = s.replace(miles, "").replace(dec, '.')
        } else if (punto >= 0 || coma >= 0) {
            val sep = if (punto >= 0) '.' else ','
            val partes = s.split(sep)
            s = if (partes.size > 2 || partes.last().length == 3) s.replace(sep.toString(), "")
                else s.replace(sep, '.')
        }
        return s.toDoubleOrNull() ?: 0.0
    }

    fun decimal(s: String): Double = s.replace(",", ".").toDoubleOrNull() ?: 0.0
}
