package ar.eds.semaforo

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.LinearLayout
import android.widget.TextView

class SemaforoService : AccessibilityService() {

    private val paquetes = setOf("com.ubercab.driver")
    private val handler = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var vista: LinearLayout? = null
    private var luz: View? = null
    private var linea1: TextView? = null
    private var linea2: TextView? = null
    private var ultimoTextoGuardado = ""

    private val analizarRunnable = Runnable { analizar() }
    private val ocultarRunnable = Runnable { ocultar() }

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (pkg !in paquetes) return
        // Junta ráfagas de eventos y analiza una sola vez, rápido.
        handler.removeCallbacks(analizarRunnable)
        handler.postDelayed(analizarRunnable, 120)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        ocultar()
        super.onDestroy()
    }

    private fun analizar() {
        val textos = mutableListOf<String>()
        try {
            for (w in windows) {
                val root = w.root ?: continue
                if (root.packageName?.toString() in paquetes) recolectar(root, textos, 0)
            }
            if (textos.isEmpty()) rootInActiveWindow?.let {
                if (it.packageName?.toString() in paquetes) recolectar(it, textos, 0)
            }
        } catch (_: Exception) {
            return
        }

        if (Prefs.diagnostico(this)) {
            val t = textos.joinToString("\n").take(4000)
            if (t.isNotBlank() && t != ultimoTextoGuardado) {
                ultimoTextoGuardado = t
                Prefs.setUltimoTexto(this, t)
            }
        }

        val oferta = Parser.parsear(textos)
        if (oferta == null) {
            handler.removeCallbacks(ocultarRunnable)
            handler.postDelayed(ocultarRunnable, 1500)
            return
        }
        val r = Evaluador.evaluar(
            oferta, Prefs.costoKm(this), Prefs.objetivoHora(this), Prefs.banda(this)
        )
        mostrar(r, oferta)
    }

    private fun recolectar(n: AccessibilityNodeInfo, out: MutableList<String>, prof: Int) {
        if (prof > 40) return
        n.text?.toString()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
        n.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
        for (i in 0 until n.childCount) {
            val hijo = n.getChild(i) ?: continue
            recolectar(hijo, out, prof + 1)
        }
    }

    private fun dp(v: Float) =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics).toInt()

    private fun crearVista() {
        if (vista != null) return
        val fondo = GradientDrawable().apply {
            setColor(0xEE15171A.toInt())
            cornerRadius = dp(18f).toFloat()
            setStroke(dp(2f), 0xFFF2C230.toInt())
        }
        val circulo = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(54f), dp(54f))
        }
        val t1 = TextView(this).apply {
            setTextColor(0xFFECEAE4.toInt())
            textSize = 20f
            typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        }
        val t2 = TextView(this).apply {
            setTextColor(0xFFB9BCC1.toInt())
            textSize = 14f
        }
        val textos = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14f), 0, 0, 0)
            addView(t1); addView(t2)
        }
        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = fondo
            setPadding(dp(14f), dp(12f), dp(18f), dp(12f))
            addView(circulo); addView(textos)
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(70f)
        }
        try {
            wm?.addView(raiz, lp)
            vista = raiz; luz = circulo; linea1 = t1; linea2 = t2
        } catch (_: Exception) {
        }
    }

    private fun mostrar(r: Resultado, o: Oferta) {
        crearVista()
        val color = when (r.luz) {
            Luz.VERDE -> 0xFF2FBF71.toInt()
            Luz.AMARILLO -> 0xFFF2A900.toInt()
            Luz.ROJO -> 0xFFE5484D.toInt()
        }
        luz?.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
        }
        linea1?.text = "${pesos(r.netaHora)} por hora"
        linea2?.text = "Te quedan ${pesos(r.neta)} en ${dec(o.km)} km y ${o.min.toInt()} min"
        handler.removeCallbacks(ocultarRunnable)
        handler.postDelayed(ocultarRunnable, 20000)
    }

    private fun ocultar() {
        vista?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        vista = null; luz = null; linea1 = null; linea2 = null
    }
}
