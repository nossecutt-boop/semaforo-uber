package ar.eds.semaforo

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SemaforoService : AccessibilityService() {

    private val paquetes = setOf("com.ubercab.driver")
    private val handler = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var vista: LinearLayout? = null
    private var luz: View? = null
    private var linea1: TextView? = null
    private var linea2: TextView? = null
    private var ultimoTextoGuardado = ""

    // Texto que viene pegado al propio evento (sirve aunque la ventana no aparezca en la lista).
    private var textosEvento: List<String> = emptyList()
    private var momentoTextosEvento = 0L
    private var eventosUber = 0
    private var ultimaActividadGuardada = 0L

    private var analisisPendiente = false
    private var ultimaFuente: AccessibilityNodeInfo? = null
    private val analizarRunnable = Runnable {
        analisisPendiente = false
        try { analizar() } catch (_: Exception) {}
    }
    private val ocultarRunnable = Runnable { ocultar() }

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        val pkg = event.packageName?.toString()
        val esUber = pkg != null && pkg in paquetes
        if (!esUber && event.eventType != AccessibilityEvent.TYPE_WINDOWS_CHANGED) return

        if (esUber) {
            eventosUber++
            // Barato: el texto que viaja con el evento.
            val extra = mutableListOf<String>()
            event.text.forEach { t -> t?.toString()?.takeIf { it.isNotBlank() }?.let { extra.add(it) } }
            event.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { extra.add(it) }
            if (extra.isNotEmpty()) {
                textosEvento = extra
                momentoTextosEvento = SystemClock.uptimeMillis()
            }
            // Se guarda el nodo y se recorre recién en el análisis (no en cada evento).
            event.source?.let { ultimaFuente = it }
        }
        programarAnalisis()
    }

    /**
     * Analiza como mucho cada 200 ms. Antes se reiniciaba la espera con cada evento:
     * con la barra animada de "Aceptar" llegan eventos sin parar y nunca analizaba.
     */
    private fun programarAnalisis() {
        if (analisisPendiente) return
        analisisPendiente = true
        handler.postDelayed(analizarRunnable, 200)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        ocultar()
        super.onDestroy()
    }

    private fun analizar() {
        val textos = mutableListOf<String>()
        val resumenVentanas = StringBuilder()
        try {
            for (w in windows) {
                val root = w.root
                val pkg = root?.packageName?.toString() ?: "?"
                resumenVentanas.append("• ").append(tipo(w.type)).append(" | ").append(pkg)
                    .append(" | ").append(w.title ?: "").append('\n')
                if (root != null && pkg in paquetes) recolectar(root, textos, 0)
            }
            if (textos.isEmpty()) rootInActiveWindow?.let {
                if (it.packageName?.toString() in paquetes) recolectar(it, textos, 0)
            }
        } catch (_: Exception) {}

        if (textos.isEmpty()) {
            try {
                var n: AccessibilityNodeInfo? = ultimaFuente
                var tope: AccessibilityNodeInfo? = n
                var pasos = 0
                while (n != null && pasos < 60) { tope = n; n = n.parent; pasos++ }
                tope?.let { recolectar(it, textos, 0) }
            } catch (_: Exception) {}
        }
        ultimaFuente = null
        if (SystemClock.uptimeMillis() - momentoTextosEvento < 3000) textos.addAll(textosEvento)

        val oferta = Parser.parsear(textos)

        if (Prefs.diagnostico(this)) {
            val ahora = SystemClock.uptimeMillis()
            if (ahora - ultimaActividadGuardada > 1500) {
                ultimaActividadGuardada = ahora
                val hora = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
                Prefs.setActividad(
                    this,
                    "Hora: $hora\nEventos de Uber: $eventosUber\nTextos leídos: ${textos.size}\n" +
                        "Ventanas:\n$resumenVentanas"
                )
            }
            val t = textos.distinct().joinToString("\n").take(4000)
            if (t.contains("km", ignoreCase = true) && t != ultimoTextoGuardado) {
                ultimoTextoGuardado = t
                val res = if (oferta == null) "NO RECONOCIÓ OFERTA"
                    else "OFERTA: ${pesos(oferta.precio)} · ${dec(oferta.km)} km · ${oferta.min.toInt()} min"
                Prefs.setUltimoTexto(this, "$res\n—\n$t")
            }
        }

        if (oferta == null) {
            handler.removeCallbacks(ocultarRunnable)
            handler.postDelayed(ocultarRunnable, 1500)
            return
        }
        val r = Evaluador.evaluar(
            oferta, Prefs.costoKm(this), Prefs.objetivoHora(this), Prefs.banda(this)
        )
        mostrar(r, oferta)
    }

    private fun tipo(t: Int) = when (t) {
        AccessibilityWindowInfo.TYPE_APPLICATION -> "app"
        AccessibilityWindowInfo.TYPE_SYSTEM -> "sistema"
        AccessibilityWindowInfo.TYPE_INPUT_METHOD -> "teclado"
        AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY -> "overlay-acc"
        else -> "tipo$t"
    }

    private fun recolectar(n: AccessibilityNodeInfo, out: MutableList<String>, prof: Int) {
        if (prof > 40 || out.size > 400) return
        n.text?.toString()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
        n.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
        for (i in 0 until n.childCount) {
            val hijo = n.getChild(i) ?: continue
            recolectar(hijo, out, prof + 1)
        }
    }

    private fun dp(v: Float) =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics).toInt()

    private fun crearVista() {
        if (vista != null) return
        val fondo = GradientDrawable().apply {
            setColor(0xEE15171A.toInt())
            cornerRadius = dp(18f).toFloat()
            setStroke(dp(2f), 0xFFF2C230.toInt())
        }
        val circulo = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(54f), dp(54f))
        }
        val t1 = TextView(this).apply {
            setTextColor(0xFFECEAE4.toInt())
            textSize = 20f
            typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        }
        val t2 = TextView(this).apply {
            setTextColor(0xFFB9BCC1.toInt())
            textSize = 14f
        }
        val textosVista = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14f), 0, 0, 0)
            addView(t1); addView(t2)
        }
        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = fondo
            setPadding(dp(14f), dp(12f), dp(18f), dp(12f))
            addView(circulo); addView(textosVista)
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(70f)
        }
        try {
            wm?.addView(raiz, lp)
            vista = raiz; luz = circulo; linea1 = t1; linea2 = t2
        } catch (_: Exception) {}
    }

    private fun mostrar(r: Resultado, o: Oferta) {
        crearVista()
        val color = when (r.luz) {
            Luz.VERDE -> 0xFF2FBF71.toInt()
            Luz.AMARILLO -> 0xFFF2A900.toInt()
            Luz.ROJO -> 0xFFE5484D.toInt()
        }
        luz?.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
        }
        linea1?.text = "${pesos(r.netaHora)} por hora"
        linea2?.text = "Te quedan ${pesos(r.neta)} en ${dec(o.km)} km y ${o.min.toInt()} min"
        handler.removeCallbacks(ocultarRunnable)
        handler.postDelayed(ocultarRunnable, 20000)
    }

    private fun ocultar() {
        vista?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        vista = null; luz = null; linea1 = null; linea2 = null
    }
}
