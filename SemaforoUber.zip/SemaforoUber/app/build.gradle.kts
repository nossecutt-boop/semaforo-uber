plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ar.eds.semaforo"
    compileSdk = 34

    defaultConfig {
        applicationId = "ar.eds.semaforo"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"
    }
    signingConfigs {
        create("fija") {
            storeFile = file("semaforo.jks")
            storePassword = "semaforo123"
            keyAlias = "semaforo"
            keyPassword = "semaforo123"
        }
    }
    buildTypes {
        debug { signingConfig = signingConfigs.getByName("fija") }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fija")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
